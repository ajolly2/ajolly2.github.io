Searx was created by Adam Tauber and is maintained by Adam Tauber and Alexandre Flament.

Major contributing authors:

- Adam Tauber <asciimoo@gmail.com> `@asciimoo <https://github.com/asciimoo>`_
- Matej Cotman
- Thomas Pointhuber
- Alexandre Flament `@dalf <https://github.com/dalf>`_
- @Cqoicebordel

People who have submitted patches/translates, reported bugs, consulted features or
generally made searx better:

- Laszlo Hammerl
- Stefan Marsiske
- Gabor Nagy
- @pw3t
- @rhapsodhy
- András Veres-Szentkirályi
- Benjamin Sonntag
- @HLFH
- @TheRadialActive
- @Okhin
- André Koot
- Alejandro León Aznar
- rike
- dp
- Martin Zimmermann
- @courgette
- @kernc
- @Reventl0v
- Caner Başaran
- Benjamin Sonntag
- @opi
- @dimqua
- Giorgos Logiotatidis
- Luc Didry
- Niklas Haas
- @underr
- Emmanuel Benazera
- @GreenLunar
- Noemi Vanyi
- Kang-min Liu
- Kirill Isakov
- Guilhem Bonnefille
- Marc Abonce Seguin

- @jibe-b
- Christian Pietsch @pietsch
- @Maxqia
- Ashutosh Das @pyprism
- YuLun Shih @imZack
- Dmitry Mikhirev @mikhirev
